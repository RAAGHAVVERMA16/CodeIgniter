
<?php
class User extends CI_Model{

  function getAll(){

    $q = $this->db->get('user');
    if($q->num_rows() >0){
    foreach ($q->result() as $row)
    {
     $data[] =$row;
    }
     return $data;
   }
 }
 function delete_row($id)
	{
	//$this->db->query("delete  from `user` where id=$id");
  $this -> db -> where('id', $id);
  $this -> db -> delete('user');
	}	
  function updatedata($data, $id)
{
    $this->db->where('id', $id);
    return $this->db->update('user', $data);
}
  function get_row($id)
{$this->db->where('id', $id);
	$query = $this->db->get('user');
  return $query->row();
}


}
?>