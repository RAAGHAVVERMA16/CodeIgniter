<?php 
   class Test extends CI_Controller {
      public function index() { 
         
         echo "Hello World!";
         $this->load->view('home');

      } 
   } 
?>