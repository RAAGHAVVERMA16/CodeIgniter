<?php
class Dropdown extends CI_Controller
{
        Public function index()
        {
            $data['options'] = array();

            $query = $this->db->get('class1');

            if ($query->num_rows() > 0) 
            {
                foreach ($query->result() as $row)
                {
                    $data['options'][$row->id] = $row->class_name;
                }
                
            }
           
            $data = $this->lang->line('class');
            //$data['selectedClass'] = $this->input->get('class');
            $this->load->view('Class_form', $data);
        }
}
?>