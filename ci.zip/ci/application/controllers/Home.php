<?php


class Home extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        $this->load->helper('url');
        //$this->load->model('User'); ///load model
    }
    function index()
    {

        $this->load->view('form');
    }
    function list()
    {

        $data['list'] = $this->db->get('user')->result_array();

        $this->load->view('home', $data);
    }

    function store()
    {

        print_r($this->input->post());
        
        $data = array(  
            'name'     => $this->input->post('name'),  
            'email'  => $this->input->post('email'),  
            'gender'   => $this->input->post('gender'),  
            'password' => md5($this->input->post('password'))  
        );  

        $this->db->insert('user',$data);


        die("y");
        $this->load->view('form');
    }
}
