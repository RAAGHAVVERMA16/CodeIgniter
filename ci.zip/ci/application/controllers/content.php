<?php
class Content extends CI_Controller{
  
  Public function index(){
	 $data['view_file']='Cont';

	  $this->load->view('layout',$data);
  }
  Public function add() {
  
	$data['options'] = array();

	$query = $this->db->get('class1');

	if ($query->num_rows() > 0) 
	{
		foreach ($query->result() as $row)
		{
			$data['options'][$row->id] = $row->class_name;
		}
		
	}
   

  $data['view_file']='form';
  $this->load->view('layout',$data);


  //$this->insert_user->form_insert($data);
 
  //Loading View */
 

  
  }
  Public function test(){
	 $data['view_file']='Upload_Form';
	  $this->load->view('layout',$data);
  }
  public function __construct()
  {
	  parent::__construct();

	  $this->load->helper('url');
	  $this->load->model('User'); ///load model
  }
//  function indexx()
//  {

	  //$this->load->view('form');
 // }
  function list()
  {
	  $data['view_file']='home';
	  $data['list'] = $this->db->get('user')->result_array();

	  

	  $this->load->view('layout', $data);
  }
  function store()
  {

	  print_r($this->input->post());
	  
	  $data = array(  
		  'name'     => $this->input->post('name'),  
		  'email'  => $this->input->post('email'),  
		  'address'   => $this->input->post('address'),
		  'gender'   => $this->input->post('gender')  
	   
	  );  

	  $this->db->insert('user',$data);

  }
  function login(){

	  $data['view_file']='login';
	  $this->load->view('layout',$data);
  }
 
  function update($id=null){

    if($this->input->post('flag')=="update"){
		$id =  $this->input->post('id');
		$data =[
		   'name'     => $this->input->post('name'),  
		   'email'  => $this->input->post('email'),  
		   'address'   => $this->input->post('address'),
		   'gender'   => $this->input->post('gender')  
	   ]; 
		$this->User->updatedata($data,$id);
		redirect(base_url('content/List'));
	}

    $data['user'] = $this->User->get_row($id);
	
	$data['view_file']='Update_form';
	$this->load->view('layout',$data);
  
}


function delete($id){
	$this->load->model("User");
    $this->User->delete_row($id);
	redirect(base_url('content/List'));
	
}

}

?>