<?php
  
   class Form extends CI_Controller { 


      public function index() { 
         /* Load form helper */ 
       
			
         /* Load form validation library */ 
        
		$this->load->view('myform'); 
      }

      public function add() { 
       // echo "drg";
      
      
       // $this->load->view('formsuccess');
       
      $this->form_validation->set_rules('name', 'Name', 'required'); 
      $this->form_validation->set_rules('name1', 'Name', 'required'); 
           
        if ($this->form_validation->run() == FALSE) { 
            // print_r(validation_errors());
            // die("sdf");
           $this->load->view('myform'); 
        } 
        else { 
           $this->load->view('formsuccess'); 
        }

      }
   }
?>