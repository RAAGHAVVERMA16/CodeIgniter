<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <form>
    <label for="Users">Select user class</label>
<select class="form-control" name="">
    <option value=""></option>
    <?php
   $stateClass = $this->lang->line('classes');
    foreach ($stateClass as $key => $value) 
    {
      
    ?>
    <option><?php echo $value; ?></option>
    <?php
    }
    ?>
</select>
        <label for="class_name">Class name</label>
        <select name="class_name">
            <option value=""></option>
            <?php foreach ($options as $id => $class_name) 
            { ?>
                <option value="<?php echo $id; ?>"><?php echo $class_name; ?></option>
            <?php 
            } ?>
        </select>
        
        <input type="text" name="other_field">
        <button type="submit">Submit</button>
    </form>
</body>
</html>