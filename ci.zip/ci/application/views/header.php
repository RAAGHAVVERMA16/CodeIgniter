<!DOCTYPE html>
<html lang="en">
<head>
 
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"> 
  <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet"> 
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href=<?php echo base_url('content') ;?>>  
        <img src=<?php echo base_url()?>assets\img12.jpg id="#logo" height="50px" width="50px"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
        </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                  
                   <li class="nav-item">
                        <a class="nav-link" href=<?php echo base_url('content/List') ;?>>List</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href=<?php echo base_url('content') ;?>>Home</a>
                    </li>  
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>  
                   
                    <li class="nav-item">
                        <a class="nav-link" href=<?php echo base_url('content/add') ;?>>Registration</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href=<?php echo base_url('content/login') ;?>>Login</a>
                    </li>
                   
                   
                </ul>
            </div>
        </div>
  <form class="d-flex">
        <input class="form-control me-3" type="text" placeholder="Search">
        <button class="btn btn-primary" type="button">Search</button>
  </form>
</nav>