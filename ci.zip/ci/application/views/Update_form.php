<div class="container">
    <h2>Updation Form</h2>
    <?php echo @$message; ?>
    <form method="post" enctype="multipart/form-data" action="<?php echo base_url('content/update/'); ?>">
        <input type="hidden" name="id" value="<?php echo $user->id; ?>">
        <input type="hidden" name="flag" value="update">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" name="name" value="<?php echo $user->name; ?>" placeholder="Enter Name">
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" name="email" value="<?php echo $user->email; ?>" placeholder="Enter Email ID">
        </div>

       

        <div class="form-group">
            <label for="Address">Address:</label>
            <input type="text" class="form-control" name="address" value="<?php echo $user->address; ?>" placeholder="Address">
        </div>
        <div class="form-group">
            <label for="gender">Gender:</label>
            <input type="radio" value="male" name="gender" <?php echo ($user->gender == 'male') ? 'checked' : ''; ?>> &nbsp; male
            <input type="radio" value="female" name="gender" <?php echo ($user->gender == 'female') ? 'checked' : ''; ?>> &nbsp; female
            <input type="radio" value="other" name="gender" <?php echo ($user->gender == 'other') ? 'checked' : ''; ?>> &nbsp; Other
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
  </form>
</div>
