<?php
$this->load->view('header.php');
$this->load->view($view_file);
$this->load->view('footer.php');
?>