<?php  ?> 


<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>


<h2>User Table</h2>

<table>
  <tr>
    <th>S R</th>
    <th>Profile</th>
    <th>Namer</th>
    <th>Email</th>
    <th>Gender</th>
    <th>address</th>
    <th>Action</th>
  </tr>
  <?php
  
    // output data of each row
    $i=1;
   foreach ($list as $key => $row) {
  

      $image ="";
      if ($row['image']){ 
$image= $row['image'];
      } else{
        $image= "download.jpg";
      }
       
        ?>
     
    
  <tr>
    <td><?php echo $i++ ?></td>
    <td>

      <img src="assets/images/user/<?php echo $image; ?>" id="#logo" height="50px" width="50px">
  

     </td>

    <td><?php echo $row['name'] ?></td>
    <td><?php echo $row['email'] ?></td>
    <td><?php echo $row['gender'] ?></td>
    <td><?php echo $row['address'] ?></td>
    <td><a href="<?php echo base_url('content/delete/' . $row['id']); ?>">Delete</a>
    <a href="<?php echo base_url('content/update/'.$row['id']); ?>">Update</a></td>
    
    
  </tr>
<?php } 
   ?>
 
<?php ?>
</table>