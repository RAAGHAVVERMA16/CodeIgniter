<!-- <!DOCTYPE html> -->
 <!-- <html>  
/*<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>*/ -->

 <div class="container">
  <h2>Registration Form</h2>
  <?php echo @$message; ?>
  <form method="post" enctype="multipart/formdata" action="<?php echo base_url('content/store'); ?>">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" class="form-control" name="name" placeholder="Enter Name">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" name="email" placeholder="Enter Email ID">
    </div>

	 <div class="form-group"> 
      <label for="Website">Website</label>
      <input type="text" class="form-control" name="website" placeholder="Website">
    </div>

	<div class="form-group">
      <label for="Address">Address:</label>
      <input type="text" class="form-control" name="address" placeholder="Address">
    </div>
    <div class="form-group">
    <input type="radio" name="gender" > &nbsp; male 
    <input type="radio" name="gender" >  &nbsp; female 
     <input type="radio" name="gender" >  &nbsp; Other  
  
    <br></div>
<br>
<div class="form-group">
  <div class="row-4 col-md">
    <label for="class_name">Class name</label>
        <select name="class_name">
            <option value=""></option>
            <?php foreach ($options as $id => $class_name) 
            { ?>
                <option value="<?php echo $id; ?>"><?php echo $class_name; ?></option>
            <?php 
            } ?>
        </select>
  </div>
</div>            
<br>
    <input type="submit" name="register" class="btn btn-success" value="Register"/>
  </form>
</div>

